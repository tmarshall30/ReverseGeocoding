app.directive('mapContents', function () {
        return {
            templateUrl: '../views/mapContents.html'
        };
    });
    
    app.directive('leftForm', function () {
        return {
            templateUrl: '../views/leftForm.html'
        };
    });
    
    app.directive('rightContents', function () {
        return {
            templateUrl: '../views/rightContents.html'
        };
    });